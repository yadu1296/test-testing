package com.telushealth.thcp.stash.rest.client.parser;

import com.google.gson.JsonElement;
import com.telushealth.thcp.stash.rest.client.entity.Author;
import com.telushealth.thcp.stash.rest.client.entity.Commit;
import com.telushealth.thcp.stash.rest.client.entity.ProjectSshKey;

import java.util.function.Function;

public class Parsers {

    private static final CommitParser COMMIT_PARSER = new CommitParser();

    private static final AuthorParser AUTHOR_PARSER = new AuthorParser();

    private static final StringParser STRING_PARSER = new StringParser();

    private static final ProjectSshKeyParser PROJECT_SSH_KEY_PARSER = new ProjectSshKeyParser();

    public static Function<JsonElement, Commit> commitParser() {
        return COMMIT_PARSER;
    }

    public static Function<JsonElement, Author> authorParser() {
        return AUTHOR_PARSER;
    }

    public static Function<JsonElement, String> stringParser() {
        return STRING_PARSER;
    }

    public static Function<JsonElement, ProjectSshKey> projectSshKeyParser() {
        return PROJECT_SSH_KEY_PARSER;
    }
}
