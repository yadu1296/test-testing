package com.telushealth.thcp.stash.rest.client;

import com.atlassian.stash.rest.client.api.StashError;
import com.atlassian.stash.rest.client.api.StashRestException;
import com.atlassian.stash.rest.client.api.StashUnauthorizedRestException;
import com.atlassian.stash.rest.client.api.entity.Page;
import com.atlassian.stash.rest.client.api.entity.ProjectPermission;
import com.atlassian.stash.rest.client.api.entity.UserSshKey;
import com.atlassian.stash.rest.client.core.http.HttpMethod;
import com.atlassian.stash.rest.client.core.http.HttpRequest;
import com.atlassian.stash.rest.client.core.http.HttpResponse;
import com.atlassian.stash.rest.client.core.http.UriBuilder;
import com.google.common.io.CharStreams;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.telushealth.thcp.stash.rest.client.entity.Commit;
import com.telushealth.thcp.stash.rest.client.entity.ProjectSshKey;
import com.telushealth.thcp.stash.rest.client.entity.RestCreateBranchRequest;
import org.apache.http.HttpEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.log4j.Logger;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.BufferedReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

import static com.atlassian.stash.rest.client.api.StashException.toErrors;
import static com.atlassian.stash.rest.client.core.http.HttpMethod.*;
import static com.atlassian.stash.rest.client.core.parser.Parsers.errorsParser;
import static com.atlassian.stash.rest.client.core.parser.Parsers.pageParser;
import static com.telushealth.thcp.stash.rest.client.parser.Parsers.commitParser;
import static com.telushealth.thcp.stash.rest.client.parser.Parsers.projectSshKeyParser;
import static com.telushealth.thcp.stash.rest.client.parser.Parsers.stringParser;
import static java.net.HttpURLConnection.HTTP_UNAUTHORIZED;

public class StashClientImpl extends com.atlassian.stash.rest.client.core.StashClientImpl implements StashClient {

    private static final Logger log = Logger.getLogger(StashClientImpl.class);
    private static final BiConsumer<UriBuilder, Long> START_PARAM_ENCODER = (uriBuilder, start) -> uriBuilder
            .addQueryParam("start", Long.toString(start));
    private static final BiConsumer<UriBuilder, Long> LIMIT_PARAM_ENCODER = (uriBuilder, limit) -> uriBuilder
            .addQueryParam("limit", (limit > 0) ? Long.toString(limit) : null);
    private HttpClientHttpExecutor httpExecutor;

    public StashClientImpl(HttpClientHttpExecutor httpExecutor, int pageLimit) {

        super(httpExecutor, pageLimit);
        this.httpExecutor = httpExecutor;
    }

    public StashClientImpl(HttpClientHttpExecutor httpExecutor) {

        super(httpExecutor);
        this.httpExecutor = httpExecutor;
    }

    @Override
    public void setDefaultBranch(@Nonnull String projectKey, @Nonnull String repositorySlug, @Nonnull String
            branchName) {

        final UriBuilder uriBuilder = UriBuilder.forPath("/rest/api/1.0/projects/%s/repos/%s/branches/default",
                projectKey, repositorySlug);

        JsonObject object = new JsonObject();
        object.addProperty("id", branchName);

        doRestCall(uriBuilder, PUT, object, false);
    }

    @Override
    public void createBranch(@Nonnull final String projectKey, @Nonnull final String repositorySlug, @Nonnull final
    String branchName, @Nullable final String startPoint, @Nonnull final String message) {


        final UriBuilder uriBuilder = UriBuilder.forPath("/rest/api/1.0/projects/%s/repos/%s/branches", projectKey,
                repositorySlug);

        if (startPoint != null) {
            RestCreateBranchRequest request = new RestCreateBranchRequest(branchName, startPoint, message);

            doRestCall(uriBuilder, POST, request.toJson(), false);
        }
        else {
            commitFile(projectKey, repositorySlug, branchName, "empty", null, "", "Initial project commit");
        }

    }

    @Override
    public Commit commitFile(@Nonnull final String projectKey, @Nonnull final String repositorySlug, @Nonnull final
    String branch, @Nonnull final String path, @Nullable final String sourceCommitId, @Nonnull final String content,
                             @Nonnull final String message) {

        final UriBuilder uriBuilder = UriBuilder.forPath("/rest/api/1.0/projects/%s/repos/%s/browse/%s", projectKey,
                repositorySlug, path);

        final MultipartEntityBuilder builder = MultipartEntityBuilder.create();
        builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
        builder.addBinaryBody("content", content.getBytes(), ContentType.DEFAULT_BINARY, path);
        builder.addTextBody("branch", branch, ContentType.TEXT_PLAIN);
        builder.addTextBody("message", message, ContentType.TEXT_PLAIN);
        if (sourceCommitId != null) {
            builder.addTextBody("sourceCommitId", sourceCommitId, ContentType.APPLICATION_JSON);
        }

        final HttpEntity entity = builder.build();
        final JsonElement jsonElement = doMultipartHttpCall(uriBuilder, PUT, entity);
        return commitParser().apply(jsonElement);
    }

    @Override
    public Page<Commit> getCommits(@Nonnull final String projectKey, @Nonnull final String repositorySlug, boolean
            followRenames, boolean ignoreMissing, @Nullable String merges, @Nullable String path, @Nullable String
            since, @Nullable String until, boolean withCounts, long start, long limit) {
        final UriBuilder uriBuilder = UriBuilder.forPath("/rest/api/1.0/projects/%s/repos/%s/commits", projectKey,
                repositorySlug).encodeQueryParam(start, START_PARAM_ENCODER).encodeQueryParam(limit,
                LIMIT_PARAM_ENCODER).addQueryParam("followRenames", Boolean.toString(followRenames)).addQueryParam
                ("ignoreMissing", Boolean.toString(ignoreMissing)).addQueryParam("merges", merges).addQueryParam
                ("path", path).addQueryParam("since", since).addQueryParam("until", until).addQueryParam
                ("withCounts", Boolean.toString(withCounts));

        final JsonElement jsonElement = doRestCall(uriBuilder, GET, null, false);
        if (jsonElement.getAsJsonObject().get("nextPageStart").isJsonNull()) {
            jsonElement.getAsJsonObject().addProperty("nextPageStart", -1);
        }

        return pageParser(commitParser()).apply(jsonElement);
    }

    @Override
    public Commit getCommit(@Nonnull String projectKey, @Nonnull String repositorySlug, @Nonnull String id) {

        final UriBuilder uriBuilder = UriBuilder.forPath("/rest/api/1.0/projects/%s/repos/%s/commits/%s", projectKey,
                repositorySlug, id);


        final JsonElement jsonElement = doRestCall(uriBuilder, GET, null, false);

        return commitParser().apply(jsonElement);
    }

    @Override
    public String getRaw(@Nonnull String projectKey, @Nonnull String repositorySlug, @Nonnull String path, @Nullable
            String commit) {

        final UriBuilder uriBuilder = UriBuilder.forPath("/rest/api/1.0/projects/%s/repos/%s/raw/%s", projectKey,
                repositorySlug, path).addQueryParam("at", commit);

        return doHttpCall(uriBuilder.build(), GET, null, false);
    }

    @Override
    public Page<String> getFiles(@Nonnull String projectKey, @Nonnull String repositorySlug, @Nonnull String commit,
                                 final long start, final long limit) {
        final UriBuilder uriBuilder = UriBuilder.forPath("/rest/api/1.0/projects/%s/repos/%s/files", projectKey, repositorySlug)
                                      .addQueryParam("at", commit)
                                      .encodeQueryParam(limit, LIMIT_PARAM_ENCODER)
                                      .encodeQueryParam(start, START_PARAM_ENCODER);
        final JsonElement jsonElement = doRestCall(uriBuilder, GET, null, false);
        if (jsonElement.getAsJsonObject().get("nextPageStart").isJsonNull()) {
            jsonElement.getAsJsonObject().addProperty("nextPageStart", -1);
        }
        return pageParser(stringParser()).apply(jsonElement);
    }

    @Override
    public Page<ProjectSshKey> getProjectSshKeys(@Nonnull String projectKey, long start, long limit) {
        final UriBuilder uriBuilder = UriBuilder.forPath("/rest/keys/1.0/projects/%s/ssh", projectKey).
                encodeQueryParam(start, START_PARAM_ENCODER).encodeQueryParam(limit,LIMIT_PARAM_ENCODER);

        final JsonElement jsonElement = doRestCall(uriBuilder, GET, null, false);
//        if (jsonElement.getAsJsonObject().get("nextPageStart").isJsonNull()) {
//            jsonElement.getAsJsonObject().addProperty("nextPageStart", -1);
//        }

        return pageParser(projectSshKeyParser()).apply(jsonElement);
    }

    @Override
    public void addProjectSshKey(@Nonnull String projectKey, long keyId, @Nonnull String publicKey, @Nonnull String
            permission) {

        UserSshKey key = new UserSshKey(keyId, publicKey, null);
        final ProjectSshKey payload = new ProjectSshKey(key, null, ProjectPermission.valueOf(permission));

        final UriBuilder uriBuilder =
                UriBuilder.forPath("/rest/keys/1.0/projects/%s/ssh", projectKey);

        doRestCall(uriBuilder, POST, payload.toJson(), false);
    }

    private JsonElement doMultipartHttpCall(UriBuilder uriBuilder, HttpMethod method, HttpEntity entity) {

        try {
            httpExecutor.multipartUpload(uriBuilder.build(), method, entity, response -> {
                String responseString = null;
                if (response.getBodyStream() != null) {
                    responseString = CharStreams.toString(new BufferedReader(response.getBodyReader(StandardCharsets
                            .UTF_8.name())));
                }
                if (log.isTraceEnabled()) {
                    log.trace(String.format("doMultipartHttpCall response: code=%d; response='%s'", response
                            .getStatusCode(), responseString));
                }

                if (response.isSuccessful()) {
                    if (responseString != null) {
                        try {
                            JsonElement jsonElement = new JsonParser().parse(responseString);
                            return jsonElement != null && !jsonElement.isJsonNull() ? jsonElement : null;
                        }
                        catch (JsonSyntaxException e) {
                            throw createStashRestException(response, toErrors("Failed to parse response: " + e
                                    .getMessage()), responseString);
                        }
                    }
                    return null;
                }
                else {
                    List<StashError> errors;
                    try {
                        if (responseString != null) {
                            JsonElement jsonElement = new JsonParser().parse(responseString);
                            if (jsonElement != null && jsonElement.isJsonObject()) {
                                errors = errorsParser().apply(jsonElement);
                            }
                            else {
                                errors = toErrors("Request to Stash failed. Returned with " + response.getStatusCode
                                        () + ". Response body is empty.");
                            }
                        }
                        else {
                            errors = new ArrayList<>();
                        }
                    }
                    catch (JsonSyntaxException entityException) {
                        errors = toErrors("Request to Stash failed. Returned with " + response.getStatusCode());
                    }
                    throw createStashRestException(response, errors, responseString);
                }
            });
        }
        catch (RuntimeException e) {
            if (log.isTraceEnabled()) {
                log.trace(e, e);
            }
            throw e;
        }

        return null;
    }

    private String doHttpCall(@Nonnull String requestUrl, @Nonnull HttpMethod methodType, @Nullable JsonObject
            requestJson, boolean anonymousCall) {
        String requestData = requestJson != null ? requestJson.toString() : null;
        try {
            return httpExecutor.execute(new HttpRequest(requestUrl, methodType, requestData, anonymousCall), response
                    -> {
                String responseString = null;
                if (response.getBodyStream() != null) {
                    responseString = CharStreams.toString(new BufferedReader(response.getBodyReader(StandardCharsets
                            .UTF_8.name())));
                }
                if (log.isTraceEnabled()) {
                    log.trace(String.format("doRestCall response: code=%d; response='%s'", response.getStatusCode(),
                            responseString));
                }

                if (response.isSuccessful()) {
                    return responseString;
                }
                else {
                    List<StashError> errors = new ArrayList<>();
                    errors.add(new StashError("Http request failed!", null, null));
                    throw createStashRestException(response, errors, responseString);
                }
            });
        }
        catch (RuntimeException e) {
            if (log.isTraceEnabled()) {
                log.trace(e, e);
            }
            throw e;
        }
    }

    private StashRestException createStashRestException(HttpResponse response, List<StashError> errors, String
            responseString) {
        switch (response.getStatusCode()) {
            case HTTP_UNAUTHORIZED:
                return new StashUnauthorizedRestException(errors, response.getStatusCode(), response.getStatusMessage
                        (), responseString);
            default:
                return new StashRestException(errors, response.getStatusCode(), response.getStatusMessage(),
                        responseString);
        }
    }
}
