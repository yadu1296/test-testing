package com.telushealth.thcp.stash.rest.client.entity;

// import java.util.Objects;
// import com.google.common.base.Objects;
import com.google.common.base.MoreObjects;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class Author {

    private final String name;

    private final String emailAddress;

    private final long id;

    private final String displayName;

    private final boolean active;

    private final String slug;

    private final String type;

    public Author(@Nonnull final String name, @Nullable final String emailAddress, final long id, @Nonnull final
    String displayName, final boolean active, @Nonnull final String slug, @Nonnull final String type) {
        this.name = name;
        this.emailAddress = emailAddress;
        this.id = id;
        this.displayName = displayName;
        this.active = active;
        this.slug = slug;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    @Nullable
    public String getEmailAddress() {
        return emailAddress;
    }

    public long getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public boolean isActive() {
        return active;
    }

    public String getSlug() {
        return slug;
    }

    public String getType() {
        return type;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this).add("name", name).add("emailAddress", emailAddress).add("id", id).add
                ("displayName", displayName).add("isActive", active).add("slug", slug).add("type", type).toString();
    }
}
