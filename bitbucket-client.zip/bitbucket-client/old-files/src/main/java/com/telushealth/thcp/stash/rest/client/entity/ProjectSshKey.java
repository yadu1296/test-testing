package com.telushealth.thcp.stash.rest.client.entity;

import com.atlassian.stash.rest.client.api.entity.Project;
import com.atlassian.stash.rest.client.api.entity.ProjectPermission;
import com.atlassian.stash.rest.client.api.entity.UserSshKey;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class ProjectSshKey {

    private final UserSshKey key;
    private final Project project;
    private final ProjectPermission permission;

    public ProjectSshKey(UserSshKey key, Project project, ProjectPermission permission) {
        this.key = key;
        this.project = project;
        this.permission = permission;
    }

    public UserSshKey getKey() {
        return key;
    }

    public Project getProject() {
        return project;
    }

    public ProjectPermission getPermission() {
        return permission;
    }

    public JsonObject toJson() {

        Gson gson = new Gson();
        JsonParser parser = new JsonParser();

        return parser.parse(gson.toJson(this)).getAsJsonObject();
    }
}
