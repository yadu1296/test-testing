package com.telushealth.thcp.stash.rest.client;

import com.atlassian.stash.rest.client.httpclient.HttpClientConfig;

import javax.annotation.Nonnull;

public interface HttpClientStashClientFactory extends com.atlassian.stash.rest.client.httpclient
        .HttpClientStashClientFactory {

    StashClient getStashClient(@Nonnull HttpClientConfig config);
    
    StashClient getStashClient(@Nonnull HttpClientConfig config, String proxyHost, Integer proxyPort);
}
