package com.telushealth.thcp.stash.rest.client;

import com.atlassian.stash.rest.client.httpclient.HttpClientConfig;

import javax.annotation.Nonnull;

public class ClientStashClientFactoryImpl implements HttpClientStashClientFactory {

    @Override
    public StashClient getStashClient(@Nonnull HttpClientConfig config) {
        return getStashClient(config, null, null);
    }
    
    @Override
    public StashClient getStashClient(@Nonnull HttpClientConfig config, String proxyHost, Integer proxyPort) {
      HttpClientHttpExecutor httpExecutor = new HttpClientHttpExecutor(config, proxyHost, proxyPort);
      return new StashClientImpl(httpExecutor);
    }
}
