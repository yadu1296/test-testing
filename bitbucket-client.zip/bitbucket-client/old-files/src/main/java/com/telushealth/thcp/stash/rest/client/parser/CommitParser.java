package com.telushealth.thcp.stash.rest.client.parser;

import com.atlassian.stash.rest.client.core.parser.ParserUtil;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.telushealth.thcp.stash.rest.client.entity.BaseCommit;
import com.telushealth.thcp.stash.rest.client.entity.Commit;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.function.Function;

import static com.telushealth.thcp.stash.rest.client.parser.Parsers.authorParser;

public class CommitParser implements Function<JsonElement, Commit> {

    @Nullable
    @Override
    public Commit apply(@Nullable final JsonElement json) {
        if (json == null) {
            return null;
        }
        JsonObject jsonObject = json.getAsJsonObject();
        return new Commit(jsonObject.get("id").getAsString(), jsonObject.get("displayId").getAsString(), authorParser
                ().apply(jsonObject.get("author").getAsJsonObject()), getTimestamp(jsonObject, "authorTimestamp"),
                authorParser().apply(jsonObject.get("committer").getAsJsonObject()), getTimestamp(jsonObject,
                "committerTimestamp"), jsonObject.get("message").getAsString(), getParentCommits(jsonObject.get
                ("parents")));
    }


    private List<BaseCommit> getParentCommits(JsonElement json) {

        List<BaseCommit> commits = new ArrayList<>();

        if (json != null) {
            JsonArray array = json.getAsJsonArray();
            for (JsonElement element : array) {
                JsonObject object = element.getAsJsonObject();
                BaseCommit baseCommit = new BaseCommit(object.get("id").getAsString(), object.get("displayId")
                        .getAsString());
                commits.add(baseCommit);
            }

        }
        return commits;
    }

    private Date getTimestamp(JsonObject jsonObject, String field) {
        final Long timestamp = ParserUtil.getOptionalJsonLong(jsonObject, field);
        if (timestamp == null) {
            return null;
        }
        return new Date(timestamp);
    }
}
