package com.telushealth.thcp.stash.rest.client.parser;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.telushealth.thcp.stash.rest.client.entity.Author;

import java.util.function.Function;

public class AuthorParser implements Function<JsonElement, Author> {

    @Override
    public Author apply(JsonElement json) {

        if (json == null) {
            return null;
        }
        JsonObject jsonObject = json.getAsJsonObject();
        return new Author(
                jsonObject.get("name").getAsString(),
                jsonObject.get("emailAddress").getAsString(),
                jsonObject.get("id") == null? 0 : jsonObject.get("id").getAsLong(),
                jsonObject.get("displayName") == null? "" : jsonObject.get("displayName").getAsString(),
                jsonObject.get("active") == null? false : jsonObject.get("active").getAsBoolean(),
                jsonObject.get("slug") == null? "" : jsonObject.get("slug").getAsString(),
                jsonObject.get("type") == null? "" : jsonObject.get("type").getAsString());
    }
}
