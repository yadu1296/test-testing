package com.telushealth.thcp.stash.rest.client;

import com.atlassian.stash.rest.client.api.StashError;
import com.atlassian.stash.rest.client.api.StashException;
import com.atlassian.stash.rest.client.api.StashRestException;
import com.atlassian.stash.rest.client.api.StashUnauthorizedRestException;
import com.atlassian.stash.rest.client.api.entity.Page;
import com.atlassian.stash.rest.client.api.entity.ProjectPermission;
import com.atlassian.stash.rest.client.api.entity.UserSshKey;
import com.atlassian.stash.rest.client.core.http.HttpMethod;
import com.atlassian.stash.rest.client.core.http.HttpRequest;
import com.atlassian.stash.rest.client.core.http.HttpResponse;
import com.atlassian.stash.rest.client.core.http.UriBuilder;
import com.atlassian.stash.rest.client.httpclient.HttpClientConfig;
import com.google.common.io.CharStreams;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.telushealth.thcp.stash.rest.client.entity.Commit;
import com.telushealth.thcp.stash.rest.client.entity.ProjectSshKey;
import com.telushealth.thcp.stash.rest.client.entity.RestCreateBranchRequest;
import org.apache.http.HttpEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.log4j.Logger;
import org.springframework.http.RequestEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.BufferedReader;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

import static com.atlassian.stash.rest.client.api.StashException.toErrors;
import static com.atlassian.stash.rest.client.core.http.HttpMethod.GET;
import static com.atlassian.stash.rest.client.core.http.HttpMethod.POST;
import static com.atlassian.stash.rest.client.core.http.HttpMethod.PUT;
import static com.atlassian.stash.rest.client.core.parser.Parsers.errorsParser;
import static com.atlassian.stash.rest.client.core.parser.Parsers.pageParser;
import static com.telushealth.thcp.stash.rest.client.parser.Parsers.commitParser;
import static com.telushealth.thcp.stash.rest.client.parser.Parsers.projectSshKeyParser;
import static com.telushealth.thcp.stash.rest.client.parser.Parsers.stringParser;
import static java.net.HttpURLConnection.HTTP_UNAUTHORIZED;

public class StashClientImpl extends com.atlassian.stash.rest.client.core.StashClientImpl implements StashClient {

    private static final Logger log = Logger.getLogger(StashClientImpl.class);
    private static final BiConsumer<UriBuilder, Long> START_PARAM_ENCODER = (uriBuilder, start) -> uriBuilder
            .addQueryParam("start", Long.toString(start));
    private static final BiConsumer<UriBuilder, Long> LIMIT_PARAM_ENCODER = (uriBuilder, limit) -> uriBuilder
            .addQueryParam("limit", (limit > 0) ? Long.toString(limit) : null);
    private HttpClientHttpExecutor httpExecutor;


    private RestTemplate restTemplate = new RestTemplate();



    public StashClientImpl(HttpClientHttpExecutor httpExecutor, int pageLimit) {

        super(httpExecutor, pageLimit);
        this.httpExecutor = httpExecutor;
        URL uriBuilder = null;
        try {
             uriBuilder = new URL("https://api.github.com");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        HttpClientConfig config = new HttpClientConfig(uriBuilder,
                "yadu1296", "Yadu@1296");
        HttpClientHttpExecutor httpExecutor1 = new HttpClientHttpExecutor(config, null, null);
        this.httpExecutor = httpExecutor1;
    }

    public StashClientImpl(HttpClientHttpExecutor httpExecutor) {

        super(httpExecutor);
        this.httpExecutor = httpExecutor;
        if (this.httpExecutor == null) {

        }
    }

    @Override
    public String setDefaultBranch(@Nonnull String projectKey, @Nonnull String repositorySlug, @Nonnull String
            branchName) throws URISyntaxException {

        final UriBuilder uriBuilder = UriBuilder.forPath("/repos/%s/%s",
                repositorySlug, projectKey);

        JsonObject object = new JsonObject();
        object.addProperty("default_branch", branchName);

        String requestUrl = uriBuilder.build();

        String requestData = object != null ? object.toString() : null;


        try {
            HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
            requestFactory.setConnectTimeout(6000);
            requestFactory.setReadTimeout(6000);
            restTemplate.setRequestFactory(requestFactory);
            MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
           headers.add("Authorization", "Bearer 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");
            return restTemplate.exchange(new RequestEntity<>(requestData, headers, org.springframework.http.HttpMethod.PATCH, new URI("https://api.github.com/repos/yadu1296/atm-service-coding-test")), String.class).getBody();

        } catch (RuntimeException | URISyntaxException e) {
            if (log.isTraceEnabled()) {
                log.trace(e, e);
            }
            throw e;
        }

        //doRestCall(uriBuilder, PUT, object, false);
    }

    @Override
    public void createBranch(@Nonnull final String projectKey, @Nonnull final String repositorySlug, @Nonnull final
    String branchName, @Nullable final String startPoint, @Nonnull final String message) {


        final UriBuilder uriBuilder = UriBuilder.forPath("/rest/api/1.0/projects/%s/repos/%s/branches", projectKey,
                repositorySlug);

        if (startPoint != null) {
            RestCreateBranchRequest request = new RestCreateBranchRequest(branchName, startPoint, message);

            doRestCall(uriBuilder, POST, request.toJson(), false);
        }
        else {
            commitFile(projectKey, repositorySlug, branchName, "empty", null, "", "Initial project commit");
        }

    }

    @Override
    public Commit commitFile(@Nonnull final String projectKey, @Nonnull final String repositorySlug, @Nonnull final
    String branch, @Nonnull final String path, @Nullable final String sourceCommitId, @Nonnull final String content,
                             @Nonnull final String message) {

        final UriBuilder uriBuilder = UriBuilder.forPath("/rest/api/1.0/projects/%s/repos/%s/browse/%s", projectKey,
                repositorySlug, path);

        final MultipartEntityBuilder builder = MultipartEntityBuilder.create();
        builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
        builder.addBinaryBody("content", content.getBytes(), ContentType.DEFAULT_BINARY, path);
        builder.addTextBody("branch", branch, ContentType.TEXT_PLAIN);
        builder.addTextBody("message", message, ContentType.TEXT_PLAIN);
        if (sourceCommitId != null) {
            builder.addTextBody("sourceCommitId", sourceCommitId, ContentType.APPLICATION_JSON);
        }

        final HttpEntity entity = builder.build();
        final JsonElement jsonElement = doMultipartHttpCall(uriBuilder, PUT, entity);
        return commitParser().apply(jsonElement);
    }

    @Override
    public Page<Commit> getCommits(@Nonnull final String projectKey, @Nonnull final String repositorySlug, boolean
            followRenames, boolean ignoreMissing, @Nullable String merges, @Nullable String path, @Nullable String
            since, @Nullable String until, boolean withCounts, long start, long limit) {
        final UriBuilder uriBuilder = UriBuilder.forPath("https://api.github.com/repos/%s/%s/commits", projectKey,
                repositorySlug).encodeQueryParam(start, START_PARAM_ENCODER).encodeQueryParam(limit,
                LIMIT_PARAM_ENCODER).addQueryParam("followRenames", Boolean.toString(followRenames)).addQueryParam
                ("ignoreMissing", Boolean.toString(ignoreMissing)).addQueryParam("merges", merges).addQueryParam
                ("path", path).addQueryParam("since", since).addQueryParam("until", until).addQueryParam
                ("withCounts", Boolean.toString(withCounts));

        /*final List<Commit> list = doRestCall1(uriBuilder.build(), GET, null, false);
        if (jsonElement.getAsJsonObject().get("nextPageStart").isJsonNull()) {
            jsonElement.getAsJsonObject().addProperty("nextPageStart", -1);
        }*/

        return null;
    }

    @Override
    public JsonArray getCommits(String projectKey, String repositorySlug) {
        return doRestCall1("/repos/yadu1296/atm-service-coding-test/commits", HttpMethod.GET, null, false);
//        String c = StringParser().apply(json);
//        return Arrays.asList(c);
    }

    protected JsonArray doRestCall1(@Nonnull String requestUrl, @Nonnull HttpMethod methodType,
                                    @Nullable JsonElement requestJson, boolean anonymousCall) throws StashException {

        String requestData = requestJson != null ? requestJson.toString() : null;
        if (log.isTraceEnabled()) {
            log.trace(String.format("doRestCall request: methodType=%s; requestUrl='%s'; requestJson='%s'; anonymous?=%s", methodType, requestUrl, requestJson, anonymousCall));
        }

        try {
            return httpExecutor.execute(new HttpRequest("/repos/yadu1296/atm-service-coding-test/commits", methodType, requestData, anonymousCall),
                    response -> {
                        String responseString = null;
                        if (response.getBodyStream() != null) {
                            responseString = CharStreams.toString(new BufferedReader(response.getBodyReader(StandardCharsets.UTF_8.name())));
                        }
                        if (log.isTraceEnabled()) {
                            log.trace(String.format("doRestCall response: code=%d; response='%s'", response.getStatusCode(), responseString));
                        }

                        if (response.isSuccessful()) {
                            if (responseString != null) {
                                try {

                                    JsonElement jsonElement = new JsonParser().parse(responseString);
                                    if (jsonElement.isJsonArray()) {
                                       // final ObjectMapper objectMapper = new ObjectMapper();
                                        //List<Commit> comitList = objectMapper.readValue(jsonElement.getAsJsonArray().toString(), new TypeReference<List<Commit>>(){});
                                        return jsonElement.getAsJsonArray();

                                    } else if (jsonElement.isJsonObject()) {
                                        return null;
                                    }
                                    return null;
                                } catch (JsonSyntaxException e) {
                                    throw createStashRestException(response, toErrors("Failed to parse response: " + e.getMessage()), responseString);
                                }
                            }
                            return null;
                        } else {
                            List<StashError> errors;
                            try {
                                if (responseString != null) {
                                    JsonElement jsonElement = new JsonParser().parse(responseString);
                                    if (jsonElement != null && jsonElement.isJsonObject()) {
                                        errors = errorsParser().apply(jsonElement);
                                    } else {
                                        errors = toErrors("Request to Stash failed. Returned with " + response.getStatusCode() + ". Response body is empty.");
                                    }
                                } else {
                                    errors = new ArrayList<>();
                                }
                            } catch (JsonSyntaxException entityException) {
                                errors = toErrors("Request to Stash failed. Returned with " + response.getStatusCode());
                            }
                            throw createStashRestException(response, errors, responseString);
                        }
                    });
        } catch (RuntimeException e) {
            if (log.isTraceEnabled()) {
                log.trace(e, e);
            }
            throw e;
        }
    }

    @Override
    public Commit getCommit(@Nonnull String projectKey, @Nonnull String repositorySlug, @Nonnull String id) {

        final UriBuilder uriBuilder = UriBuilder.forPath("/rest/api/1.0/projects/%s/repos/%s/commits/%s", projectKey,
                repositorySlug, id);


        final JsonElement jsonElement = doRestCall(uriBuilder, GET, null, false);

        return commitParser().apply(jsonElement);
    }

    @Override
    public String getRaw(@Nonnull String projectKey, @Nonnull String repositorySlug, @Nonnull String path, @Nullable
            String commit) {

        final UriBuilder uriBuilder = UriBuilder.forPath("/rest/api/1.0/projects/%s/repos/%s/raw/%s", projectKey,
                repositorySlug, path).addQueryParam("at", commit);

        return doHttpCall(uriBuilder.build(), GET, null, false);
    }

    @Override
    public Page<String> getFiles(@Nonnull String projectKey, @Nonnull String repositorySlug, @Nonnull String commit,
                                 final long start, final long limit) {
        final UriBuilder uriBuilder = UriBuilder.forPath("/rest/api/1.0/projects/%s/repos/%s/files", projectKey, repositorySlug)
                                      .addQueryParam("at", commit)
                                      .encodeQueryParam(limit, LIMIT_PARAM_ENCODER)
                                      .encodeQueryParam(start, START_PARAM_ENCODER);
        final JsonElement jsonElement = doRestCall(uriBuilder, GET, null, false);
        if (jsonElement.getAsJsonObject().get("nextPageStart").isJsonNull()) {
            jsonElement.getAsJsonObject().addProperty("nextPageStart", -1);
        }
        return pageParser(stringParser()).apply(jsonElement);
    }

    @Override
    public Page<ProjectSshKey> getProjectSshKeys(@Nonnull String projectKey, long start, long limit) {
        final UriBuilder uriBuilder = UriBuilder.forPath("/rest/keys/1.0/projects/%s/ssh", projectKey).
                encodeQueryParam(start, START_PARAM_ENCODER).encodeQueryParam(limit,LIMIT_PARAM_ENCODER);

        final JsonElement jsonElement = doRestCall(uriBuilder, GET, null, false);
//        if (jsonElement.getAsJsonObject().get("nextPageStart").isJsonNull()) {
//            jsonElement.getAsJsonObject().addProperty("nextPageStart", -1);
//        }

        return pageParser(projectSshKeyParser()).apply(jsonElement);
    }

    @Override
    public void addProjectSshKey(@Nonnull String projectKey, long keyId, @Nonnull String publicKey, @Nonnull String
            permission) {

        UserSshKey key = new UserSshKey(keyId, publicKey, null);
        final ProjectSshKey payload = new ProjectSshKey(key, null, ProjectPermission.valueOf(permission));

        final UriBuilder uriBuilder =
                UriBuilder.forPath("/rest/keys/1.0/projects/%s/ssh", projectKey);

        JsonElement jsonElement = doRestCall(uriBuilder, POST, payload.toJson(), false);

    }

    @Override
    public String createRepo(String repoName) {

        JsonObject object = new JsonObject();
        object.addProperty("name", repoName);
        String requestData = object != null ? object.toString() : null;

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("Authorization", "Bearer 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");
        try {
            return restTemplate.exchange(new RequestEntity<>(requestData, headers, org.springframework.http.HttpMethod.POST, new URI("https://api.github.com/user/repos")), String.class).getBody();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        return null;
    }

    private JsonElement doMultipartHttpCall(UriBuilder uriBuilder, HttpMethod method, HttpEntity entity) {

        try {
            httpExecutor.multipartUpload(uriBuilder.build(), method, entity, response -> {
                String responseString = null;
                if (response.getBodyStream() != null) {
                    responseString = CharStreams.toString(new BufferedReader(response.getBodyReader(StandardCharsets
                            .UTF_8.name())));
                }
                if (log.isTraceEnabled()) {
                    log.trace(String.format("doMultipartHttpCall response: code=%d; response='%s'", response
                            .getStatusCode(), responseString));
                }

                if (response.isSuccessful()) {
                    if (responseString != null) {
                        try {
                            JsonElement jsonElement = new JsonParser().parse(responseString);
                            return jsonElement != null && !jsonElement.isJsonNull() ? jsonElement : null;
                        }
                        catch (JsonSyntaxException e) {
                            throw createStashRestException(response, toErrors("Failed to parse response: " + e
                                    .getMessage()), responseString);
                        }
                    }
                    return null;
                }
                else {
                    List<StashError> errors;
                    try {
                        if (responseString != null) {
                            JsonElement jsonElement = new JsonParser().parse(responseString);
                            if (jsonElement != null && jsonElement.isJsonObject()) {
                                errors = errorsParser().apply(jsonElement);
                            }
                            else {
                                errors = toErrors("Request to Stash failed. Returned with " + response.getStatusCode
                                        () + ". Response body is empty.");
                            }
                        }
                        else {
                            errors = new ArrayList<>();
                        }
                    }
                    catch (JsonSyntaxException entityException) {
                        errors = toErrors("Request to Stash failed. Returned with " + response.getStatusCode());
                    }
                    throw createStashRestException(response, errors, responseString);
                }
            });
        }
        catch (RuntimeException e) {
            if (log.isTraceEnabled()) {
                log.trace(e, e);
            }
            throw e;
        }

        return null;
    }

    private String doHttpCall(@Nonnull String requestUrl, @Nonnull HttpMethod methodType, @Nullable JsonObject
            requestJson, boolean anonymousCall) {
        String requestData = requestJson != null ? requestJson.toString() : null;
        try {
            return httpExecutor.execute(new HttpRequest(requestUrl, methodType, requestData, anonymousCall), response
                    -> {
                String responseString = null;
                if (response.getBodyStream() != null) {
                    responseString = CharStreams.toString(new BufferedReader(response.getBodyReader(StandardCharsets
                            .UTF_8.name())));
                }
                if (log.isTraceEnabled()) {
                    log.trace(String.format("doRestCall response: code=%d; response='%s'", response.getStatusCode(),
                            responseString));
                }

                if (response.isSuccessful()) {
                    return responseString;
                }
                else {
                    List<StashError> errors = new ArrayList<>();
                    errors.add(new StashError("Http request failed!", null, null));
                    throw createStashRestException(response, errors, responseString);
                }
            });
        }
        catch (RuntimeException e) {
            if (log.isTraceEnabled()) {
                log.trace(e, e);
            }
            throw e;
        }
    }

    private StashRestException createStashRestException(HttpResponse response, List<StashError> errors, String
            responseString) {
        switch (response.getStatusCode()) {
            case HTTP_UNAUTHORIZED:
                return new StashUnauthorizedRestException(errors, response.getStatusCode(), response.getStatusMessage
                        (), responseString);
            default:
                return new StashRestException(errors, response.getStatusCode(), response.getStatusMessage(),
                        responseString);
        }
    }
}
