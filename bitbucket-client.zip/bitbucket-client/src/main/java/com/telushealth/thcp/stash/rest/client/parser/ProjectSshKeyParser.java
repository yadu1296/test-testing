package com.telushealth.thcp.stash.rest.client.parser;

import com.atlassian.stash.rest.client.api.entity.Project;
import com.atlassian.stash.rest.client.api.entity.ProjectPermission;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.telushealth.thcp.stash.rest.client.entity.ProjectSshKey;

import java.util.function.Function;

import static com.atlassian.stash.rest.client.core.parser.Parsers.projectParser;
import static com.atlassian.stash.rest.client.core.parser.Parsers.userSshKeyParser;

public class ProjectSshKeyParser implements Function<JsonElement, ProjectSshKey> {

    @Override
    public ProjectSshKey apply(JsonElement json) {
        JsonObject jsonObject = json.getAsJsonObject();
        JsonObject projectObject = jsonObject.getAsJsonObject("project");
        Project project = projectParser().apply(projectObject);

        JsonObject key = jsonObject.getAsJsonObject("key");

        return new ProjectSshKey(userSshKeyParser().apply(key), project, ProjectPermission.valueOf(jsonObject.get
                ("permission").getAsString()));
    }
}
