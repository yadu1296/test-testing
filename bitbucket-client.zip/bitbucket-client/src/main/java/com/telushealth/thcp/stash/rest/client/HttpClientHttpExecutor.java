package com.telushealth.thcp.stash.rest.client;

import static org.apache.http.entity.ContentType.APPLICATION_JSON;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import java.util.Map;
// import java.util.*;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.StatusLine;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.protocol.BasicHttpContext;

import com.atlassian.stash.rest.client.api.StashException;
import com.atlassian.stash.rest.client.core.http.HttpMethod;
import com.atlassian.stash.rest.client.core.http.HttpRequest;
import com.atlassian.stash.rest.client.core.http.HttpResponse;
import com.atlassian.stash.rest.client.core.http.HttpResponseProcessor;
import com.atlassian.stash.rest.client.httpclient.HttpClientConfig;
// import com.google.common.base.Objects;
import com.google.common.base.MoreObjects;
// import org.apache.commons.lang3.ObjectUtils;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;

public class HttpClientHttpExecutor extends com.atlassian.stash.rest.client.httpclient.HttpClientHttpExecutor {

    private final HttpClient httpClient;
    private final URL baseUrl;
    private final BasicHttpContext forceBasicAuthContext;

    public HttpClientHttpExecutor(@Nonnull HttpClientConfig config, String proxyHost, Integer proxyPort) {
      super(config);
      this.baseUrl = config.getBaseUrl();
      URL hostUrl = config.getBaseUrl();
      String scheme = MoreObjects.firstNonNull(hostUrl.getProtocol(), "http");
      int port = hostUrl.getPort() != -1 ? hostUrl.getPort() : ("https".equalsIgnoreCase(scheme) ? 443 : 80);
      HttpHost targetHost = new HttpHost(hostUrl.getHost(), port, scheme);
      Credentials credentials = new UsernamePasswordCredentials(config.getUsername(), config.getPassword());
      
      AuthScope authScope = new AuthScope(targetHost);
      CredentialsProvider credsProvider = new BasicCredentialsProvider();
      credsProvider.setCredentials(authScope, credentials);
      
      if(proxyHost != null && proxyPort != null) {
        HttpHost proxy = new HttpHost(proxyHost, proxyPort);
        this.httpClient = HttpClientBuilder.
                            create().
                            setProxy(proxy).
                            setDefaultCredentialsProvider(credsProvider)
                            .build();
      } else {
        this.httpClient = HttpClientBuilder.
                            create().
                            setDefaultCredentialsProvider(credsProvider)
                            .build();
      }
      AuthCache authCache = new BasicAuthCache();
      BasicScheme basicAuth = new BasicScheme();
      authCache.put(targetHost, basicAuth);
      forceBasicAuthContext = new BasicHttpContext();
      forceBasicAuthContext.setAttribute(ClientContext.AUTH_CACHE, authCache);
    }
    
    public HttpClientHttpExecutor(@Nonnull HttpClientConfig config) {
        this(config, null, null);
    }

    @Nullable
    @Override
    public <T> T execute(@Nonnull HttpRequest httpRequest, @Nonnull HttpResponseProcessor<T> responseProcessor) throws StashException {
        HttpRequestBase request = null;
        try {
            request = createRequest(httpRequest);
            request.addHeader("X-Atlassian-Token", "no-check"); // prevent XSRF checks

            final org.apache.http.HttpResponse response = httpClient.execute(request, httpRequest.isAnonymous() ? null : forceBasicAuthContext);

            final StatusLine status = response.getStatusLine();
            final Map<String, String> headers = toHeaderMultimap(response.getAllHeaders());
            final HttpEntity responseEntity = response.getEntity();
            final InputStream bodyStream = (null == responseEntity) ? new ByteArrayInputStream(new byte[0]) : responseEntity.getContent();
            final HttpResponse coreResponse = new HttpResponse(status.getStatusCode(), status.getReasonPhrase(), headers, bodyStream);
            return responseProcessor.process(coreResponse);

        } catch (IOException e) {
            throw new StashException(e);
        } finally {
            if (request != null) {
                request.reset();
            }
        }
    }
    
    private HttpRequestBase createRequest(HttpRequest httpRequest) {
      URI fullUri = URI.create(baseUrl + "/" + httpRequest.getUrl()).normalize();
      final HttpEntityEnclosingRequestBase entityEnclosingRequest;
      switch (httpRequest.getMethod()) {
          case GET:
              return new HttpGet(fullUri);
          case DELETE:
              return new HttpDelete(fullUri);
          case POST:
              entityEnclosingRequest = new HttpPost(fullUri);
              break;
          case PUT:
              entityEnclosingRequest = new HttpPut(fullUri);
              break;
          default:
              throw new UnsupportedOperationException(String.format("http method %s is not supported", httpRequest.getMethod()));
      }

      final String payload = httpRequest.getPayload();
      if (payload != null) {
          entityEnclosingRequest.setEntity(new StringEntity(payload, APPLICATION_JSON));
      }
      return entityEnclosingRequest;
  }
    
    public <T> T multipartUpload(@Nonnull String url, @Nonnull HttpMethod method, @Nonnull HttpEntity
            multipartEntity, @Nonnull HttpResponseProcessor<T> responseProcessor) throws StashException {
        HttpEntityEnclosingRequestBase request = null;
        try {
            request = createEntityRequest(method, url);
            request.setEntity(multipartEntity);
            request.addHeader("X-Atlassian-Token", "no-check"); // prevent XSRF checks

            final org.apache.http.HttpResponse response = httpClient.execute(request, forceBasicAuthContext);

            final StatusLine status = response.getStatusLine();
            final Map<String, String> headers = toHeaderMultimap(response.getAllHeaders());
            final HttpEntity responseEntity = response.getEntity();
            final InputStream bodyStream = (null == responseEntity) ? new ByteArrayInputStream(new byte[0]) :
                    responseEntity.getContent();
            final HttpResponse coreResponse = new HttpResponse(status.getStatusCode(), status.getReasonPhrase(),
                    headers, bodyStream);
            return responseProcessor.process(coreResponse);

        }
        catch (IOException e) {
            throw new StashException(e);
        }
        finally {
            if (request != null) {
                request.reset();
            }
        }
    }

    private Map<String, String> toHeaderMultimap(Header[] headers) {
        Map<String, String> headerMap = Maps.newLinkedHashMap();

        for (Header header : headers) {
            String name = header.getName().toLowerCase();
            String existingValue = headerMap.get(name);
            headerMap.put(name, existingValue == null ? header.getValue() : existingValue + "," + header.getValue());
        }

        return ImmutableMap.copyOf(headerMap);
    }

    private HttpEntityEnclosingRequestBase createEntityRequest(HttpMethod method, String url) {

        URI fullUri = URI.create(baseUrl + "/" + url).normalize();
        switch (method) {
            case PUT:
                return new HttpPut(fullUri);
            case POST:
                return new HttpPost(fullUri);
            default:
                throw new UnsupportedOperationException("Method not supported");
        }
    }
}
