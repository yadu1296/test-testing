package com.telushealth.thcp.stash.rest.client;

import com.atlassian.stash.rest.client.api.entity.Page;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.telushealth.thcp.stash.rest.client.entity.Commit;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;

@RestController
@RequestMapping("/github")
public class GitHubController {



    private StashClient stashClient = new StashClientImpl(null, 0);

    @RequestMapping(value = "/setdefaultbranch/{branchName}", method = RequestMethod.PATCH)
    public void setDefaultBranch(@PathVariable String branchName) throws Exception {
        stashClient.setDefaultBranch("yadu1296", "atm-service-coding-test", branchName);
    }

    @RequestMapping(value = "/getCommits", method = RequestMethod.GET)
    public JsonArray getCommits() throws Exception {
        return stashClient.getCommits("yadu1296", "atm-service-coding-test");
    }

    @RequestMapping(value = "/create-repo", method = RequestMethod.POST)
    public String createRepo(@RequestParam(value = "repoName") String repoName) throws Exception {
        return stashClient.createRepo(repoName);
    }


}
