package com.telushealth.thcp.stash.rest.client.entity;

public class BaseCommit {

    private final String id;
    private final String displayId;

    public BaseCommit(String id, String displayId) {
        this.id = id;
        this.displayId = displayId;
    }

    public String getId() {
        return id;
    }

    public String getDisplayId() {
        return displayId;
    }

    @Override
    public String toString() {
        return "BaseCommit{" + "id='" + id + '\'' + ", displayId='" + displayId + '\'' + '}';
    }
}
