package com.telushealth.thcp.stash.rest.client.entity;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class RestCreateBranchRequest {

    private String name;
    private String startPoint;
    private String message;

    public RestCreateBranchRequest(String name, String startPoint, String message) {
        this.name = name;
        this.startPoint = startPoint;
        this.message = message;
    }

    public String getName() {
        return name;
    }

    public String getStartPoint() {
        return startPoint;
    }

    public String getMessage() {
        return message;
    }

    public JsonObject toJson() {

        Gson gson = new Gson();
        JsonParser parser = new JsonParser();

        return parser.parse(gson.toJson(this)).getAsJsonObject();
    }
}
