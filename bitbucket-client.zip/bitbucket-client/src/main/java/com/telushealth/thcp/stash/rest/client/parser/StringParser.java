package com.telushealth.thcp.stash.rest.client.parser;

import com.google.gson.JsonElement;

import java.util.function.Function;

public class StringParser implements Function<JsonElement, String> {
    @Override
    public String apply(JsonElement json) {

        if (json == null || json.isJsonNull()) {
            return null;
        }

        return json.getAsString();
    }
}
