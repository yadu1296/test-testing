package com.telushealth.thcp.stash.rest.client.entity;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class RestCommitFileRequest {

    private String branch;
    private String content;
    private String message;
    private String sourceCommitId;

    public RestCommitFileRequest(String branch, String content, String message, String sourceCommitId) {
        this.branch = branch;
        this.content = content;
        this.message = message;
        this.sourceCommitId = sourceCommitId;
    }

    public String getBranch() {
        return branch;
    }

    public String getContent() {
        return content;
    }

    public String getMessage() {
        return message;
    }

    public String getSourceCommitId() {
        return sourceCommitId;
    }

    public JsonObject toJson() {

        Gson gson = new Gson();
        JsonParser parser = new JsonParser();

        return parser.parse(gson.toJson(this)).getAsJsonObject();
    }
}
