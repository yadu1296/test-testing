package com.telushealth.thcp.stash.rest.client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GitHubSpringBootApp {

    public static void main(String[] args) {
        SpringApplication.run(GitHubSpringBootApp.class, args);
    }
}
