package com.telushealth.thcp.stash.rest.client;

import com.atlassian.stash.rest.client.api.entity.Page;
import com.google.gson.JsonArray;
import com.telushealth.thcp.stash.rest.client.entity.Commit;
import com.telushealth.thcp.stash.rest.client.entity.ProjectSshKey;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.net.URISyntaxException;

public interface StashClient extends com.atlassian.stash.rest.client.api.StashClient {

    void createBranch(@Nonnull final String projectKey, @Nonnull final String repositorySlug, @Nonnull final String
            branchName, @Nullable final String startPoint, @Nonnull final String message);

    String setDefaultBranch(@Nonnull final String projectKey, @Nonnull final String repositorySlug, @Nonnull final
    String branchName) throws URISyntaxException;

    Commit commitFile(@Nonnull final String projectKey, @Nonnull final String repositorySlug, @Nonnull final String
            branch, @Nonnull final String path, @Nonnull final String sourceCommitId, @Nonnull final String content,
                      @Nonnull final String message);

    Page<Commit> getCommits(@Nonnull final String projectKey, @Nonnull final String repositorySlug, boolean
            followRenames, boolean ignoreMissing, @Nullable String merges, @Nullable String path, @Nullable String
            since, @Nullable String until, boolean withCounts, final long start, final long limit);

    JsonArray getCommits(final String projectKey, final String repositorySlug);

    Commit getCommit(@Nonnull final String projectKey, @Nonnull final String repositorySlug, @Nonnull final String id);

    String getRaw(@Nonnull final String projectKey, @Nonnull final String repositorySlug, @Nonnull final String path,
                  @Nullable String commit);

    Page<String> getFiles(@Nonnull final String projectKey, @Nonnull final String repositorySlug, @Nonnull String
            commit, final long start, final long limit);

    Page<ProjectSshKey> getProjectSshKeys(@Nonnull final String projectKey, final long start, final long limit);

    void addProjectSshKey(@Nonnull final String projectKey, final long keyId, @Nonnull final String publicKey,
                          @Nonnull final String permission);

    String createRepo(String repoName);
}
