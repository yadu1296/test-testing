package com.telushealth.thcp.stash.rest.client.entity;

import java.util.Date;
import java.util.List;

public class Commit extends BaseCommit {

    private final Author author;
    private final Date authorTimestamp;
    private final Author committer;
    private final Date committerTimestamp;
    private final String message;
    private final List<BaseCommit> parents;

    public Commit(String id, String displayId, Author author, Date authorTimestamp, Author committer, Date
            committerTimestamp, String message, List<BaseCommit> parents) {
        super(id, displayId);
        this.author = author;
        this.authorTimestamp = authorTimestamp;
        this.committer = committer;
        this.committerTimestamp = committerTimestamp;
        this.message = message;
        this.parents = parents;
    }

    public Author getAuthor() {
        return author;
    }

    public Date getAuthorTimestamp() {
        return authorTimestamp;
    }

    public Author getCommitter() {
        return committer;
    }

    public Date getCommitterTimestamp() {
        return committerTimestamp;
    }

    public String getMessage() {
        return message;
    }

    public List<BaseCommit> getParents() {
        return parents;
    }

    @Override
    public String toString() {
        return "Commit{" + "id='" + getId() + '\'' + ", displayId='" + getDisplayId() + '\'' + ", author=" + author +
                ", authorTimestamp=" + authorTimestamp + ", committer=" + committer + ", committerTimestamp=" +
                committerTimestamp + ", message='" + message + '\'' + ", parents=" + getParentCommits() + '}';
    }

    private String getParentCommits() {
        StringBuilder buffer = new StringBuilder();
        buffer.append("[");
        for (BaseCommit commit : parents) {
            buffer.append(commit.toString());
        }
        buffer.append("]");
        return buffer.toString();
    }
}
